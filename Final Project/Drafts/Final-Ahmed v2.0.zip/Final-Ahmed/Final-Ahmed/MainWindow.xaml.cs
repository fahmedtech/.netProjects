﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

/*
Name: Faizan Ahmed
Collaborated with Miguel Ramirez
IT330 Final Project
Video Game Library Application
*/

//importing Libraries
using Final_Ahmed.Models;

namespace Final_Ahmed
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private int _year;

        public MainWindow()
        {
            InitializeComponent();
        }

        //Method Button: Save Game in DB
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {

            using (SimpleFormContext context = new SimpleFormContext())
            {
                //if true - continue
                if (checkIfValidated())
                {
                    VideoGame game = new VideoGame();
                    game.Title = txtTitle.Text;
                    game.Year = txtYear.Text;
                    game.Developers = txtDev.Text;
                    game.Rating = cboRating.SelectedValue.ToString();

                    if (radPS4.IsChecked.Value)
                        game.Platform = "PS4";
                    else if (radXbox1.IsChecked.Value)
                        game.Platform = "Xbox One";

                    game.Genre = cboGenre.SelectedValue.ToString();
                    game.ImageName = txtImage.Text;

                    //saving on database file
                    context.VideoGames.Add(game);
                    context.SaveChanges();

                    MessageBox.Show("Video Game has been Successfully Saved!");
                }
            }
        }

        //Method Button: Clear the Controls form
        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            lblError.Content = "";

            txtTitle.Text = "";
            txtTitle.BorderBrush = new SolidColorBrush(Colors.Black);

            txtYear.Text = "";
            txtYear.BorderBrush = new SolidColorBrush(Colors.Black);

            txtDev.Text = "";
            txtDev.BorderBrush = new SolidColorBrush(Colors.Black);

            txtImage.Text = "";
            txtImage.BorderBrush = new SolidColorBrush(Colors.Black);

            cboRating.SelectedIndex = 0;
            cboGenre.SelectedIndex = 0;

            radXbox1.IsChecked = false;
            radPS4.IsChecked = true;

            imgPhoto.Source = null;
        }

        //Method ComboBox Rating: Loads the List of Ratings into ComboBox 
        private void cboRating_Loaded(object sender, RoutedEventArgs e)
        {
            //creating a List
            List<String> RatingsList = new List<String>();
            RatingsList.Add("A");
            RatingsList.Add("B");
            RatingsList.Add("C");
            RatingsList.Add("D");
            RatingsList.Add("F");

            var comboBox = sender as ComboBox;
            comboBox.ItemsSource = RatingsList;
            comboBox.SelectedIndex = 0;
        }

        //Method ComboBox Genre: Loads the List of Genres into ComboBox
        private void cboGenre_Loaded(object sender, RoutedEventArgs e)
        {
            List<String> GenresList = new List<String>();
            GenresList.Add("Role Playing Game");
            GenresList.Add("Action Adventure");
            GenresList.Add("First Person Shooter");
            GenresList.Add("Fighting");
            GenresList.Add("Survival Horror");
            GenresList.Add("Puzzle");
            GenresList.Add("Sports");

            var comboBox = sender as ComboBox;
            comboBox.ItemsSource = GenresList;
            comboBox.SelectedIndex = 0;
        }


        //Method Boolean: Validating the Textboxes
        private Boolean checkIfValidated()
        {
            //title textbox
            if (String.IsNullOrEmpty(txtTitle.Text))
            {
                txtTitle.BorderBrush = new SolidColorBrush(Colors.Red);
                lblError.Content = "'Title' Cannot be Empty!";
                return false;
            }
            else
            {
                txtTitle.BorderBrush = new SolidColorBrush(Colors.Black);
                lblError.Content = "";
            }

            //developers textbox
            if (String.IsNullOrEmpty(txtDev.Text))
            {
                txtDev.BorderBrush = new SolidColorBrush(Colors.Red);
                lblError.Content = "'Developers' Cannot be Empty!";
                return false;
            }
            else
            {
                txtDev.BorderBrush = new SolidColorBrush(Colors.Black);
                lblError.Content = "";
            }

            //year textbox
            if (String.IsNullOrEmpty(txtYear.Text) || !int.TryParse(txtYear.Text, out _year) || _year < 1995 || _year > DateTime.Today.Year)
            {
                txtYear.BorderBrush = new SolidColorBrush(Colors.Red);
                lblError.Content = "Invalid 'Year'. Range (1995-Today)!";
                return false;
            }
            else
            {
                txtYear.BorderBrush = new SolidColorBrush(Colors.Black);
                lblError.Content = "";
            }

            //image field - checking whether .jpg format filename only
            if (String.IsNullOrEmpty(txtImage.Text) || !txtImage.Text.ToString().EndsWith(".jpg"))
            {
                txtImage.BorderBrush = new SolidColorBrush(Colors.Red);
                lblError.Content = "Invalid 'Image' Format! name.jpg";
                return false;
            }
            else
            {
                txtImage.BorderBrush = new SolidColorBrush(Colors.Black);
                lblError.Content = "";
            }


            return true;
        }

    }
}
