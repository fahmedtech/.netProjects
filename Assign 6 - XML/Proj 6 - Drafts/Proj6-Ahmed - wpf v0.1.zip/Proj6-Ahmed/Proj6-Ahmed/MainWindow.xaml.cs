﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

//importing
using System.Xml;

namespace Proj6_Ahmed
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        //list of movies collection
        private List<Movie> MovieList = null;

        public MainWindow()
        {
            InitializeComponent();
            MovieList = new List<Movie>();

        }

        private void comboBox_Loaded(object sender, RoutedEventArgs e)
        {

            //creating list for dropdown menus
            List<String> genres = new List<String>();
            genres.Add("Action");
            genres.Add("Animation");
            genres.Add("Comedy");
            genres.Add("Romance");
            genres.Add("Drama");
            genres.Add("Fantasy");
            genres.Add("Thriller");

            var comboBox = sender as ComboBox;
            comboBox.ItemsSource = genres; //assigning to ComboBox all the data
            comboBox.SelectedIndex = 0;
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var comboBox = sender as ComboBox;
            string selectedGenre = comboBox.SelectedItem as string;

            //lblName_Copy.Content = selectedMovie;
        }

        private void cboRating_Loaded(object sender, RoutedEventArgs e)
        {
            //list of movie ratings
            List<string> ratings = new List<string>();
            ratings.Add("G - General Audiences");
            ratings.Add("PG - Parental Guidance");
            ratings.Add("R - Restricted");

            var comboBox = sender as ComboBox;
            comboBox.ItemsSource = ratings;
            comboBox.SelectedIndex = 0;
        }

        private void cboRating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var comboBox = sender as ComboBox;
            string selectedRating = comboBox.SelectedItem as string;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            //creating a new movie
            Movie m = new Movie(txtName.Text, cboGenres.SelectedValue.ToString(), txtPlot.Text,
                                cboRating.SelectedValue.ToString(), txtYear.Text);


            MovieList.Add(m);

            //writing to xml 
            XmlTextWriter writer = new XmlTextWriter("movies.xml", null);

            writer.Formatting = Formatting.Indented;
            writer.IndentChar = ' ';

            writer.WriteStartElement("Movies");
            foreach(Movie x in MovieList)
            {
                writer.WriteStartElement("Movie");
                writer.WriteElementString("Name", x.Name);
                writer.WriteElementString("Genre", x.Genre);
                writer.WriteElementString("Plot", x.Plot);
                writer.WriteElementString("Rating", x.Rating);
                writer.WriteElementString("Year", x.Year);
                writer.WriteEndElement();
            }

            writer.WriteEndElement(); //end element for root 
            writer.Close();

            lblCount.Content = "Movies Count: " + MovieList.Count;

            /* testing purpose only
            
            foreach(Movie x in MovieList)
            {
                lblDelete.Content = x.Name + "\n " ;
            }*/

        }


        /*
         
        validations
        if year > 1000 or <= 9999
        correct
        convert to string
        
        else
        error

        validation 2 
        name and plot cannot be empty

        */
    }
}
