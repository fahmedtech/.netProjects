﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
Name: Faizan Ahmed
IT330 - Project 5: DePaul IT Club Form | Database 
Date: 5/15/2016
*/

using Proj5_Ahmed.Models;

namespace Proj5_Ahmed
{
    public partial class view_applications : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            using(SimpleFormContext context = new SimpleFormContext())
            {
                var applicants = context.Applicants.ToList(); 

                foreach(Applicant a in applicants)
                {
                    lblData.Text = lblData.Text + a.FirstName + "<br/>"
                                                +  a.LastName + "<br/>"
                                                + a.Gender + "<br/>"
                                                + a.DepaulID + "<br/>"
                                                + a.Major + "<br/>"
                                                + a.Email + "<br/>"
                                                + a.Cellphone;
                }
            }

        }
    }
}