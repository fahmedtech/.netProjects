﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/*
Name: Faizan Ahmed
IT330 - Project 5: DePaul IT Club Form | Database 
Date: 5/15/2016
*/

using Proj5_Ahmed.Models;
using System.Text.RegularExpressions;

namespace Proj5_Ahmed
{
    public partial class FormPage : System.Web.UI.Page
    {
        //var regex = new Regex("\\(?\\d{3}\\)?-? *\\d{3}-? *-?\\d{4}");
        private int _depaulID;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmitForm_Click(object sender, EventArgs e)
        {
            using(SimpleFormContext context = new SimpleFormContext())
            {
                if (checkValidations())
                {
                    Applicant applicant = new Applicant();
                    applicant.FirstName = txtFirstName.Text;
                    applicant.LastName = txtLastName.Text;
                    applicant.Gender = rblGender.SelectedValue;
                    applicant.DepaulID = _depaulID; //needs validation
                    applicant.Major = ddlMajor.SelectedValue;
                    applicant.Email = txtEmail.Text;
                    applicant.Cellphone = txtCellphone.Text;

                    context.Applicants.Add(applicant);
                    context.SaveChanges();

                    lblValue.Text = applicant.ID.ToString();
                }

            }

        }

        private Boolean checkValidations()
        {
            // string regex = String.Format("\\(?\\d{3}\\)?-? *\\d{3}-? *-?\\d{4}");
            Regex regex = new Regex(@"\(?\d{3}\)?-? *\d{3}-? *-?\d{4}");
            Regex rgxEmail = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");

            //validating the textboxes
            if (String.IsNullOrEmpty(txtFirstName.Text))
            {
                txtFirstName.BorderColor = System.Drawing.Color.Red;
                lblFirstnameErr.Text = "First Name cannot be Empty.";
                return false;
            }
            else
            {
                lblFirstnameErr.Text = "";
                txtFirstName.BorderColor = System.Drawing.Color.Black;
            }

            if (String.IsNullOrEmpty(txtLastName.Text))
            {
                txtLastName.BorderColor = System.Drawing.Color.Red;
                lblLastnameErr.Text = "Last Name cannot be Empty.";
                return false;
            }
            else
            {
                lblLastnameErr.Text = "";
                txtLastName.BorderColor = System.Drawing.Color.Black;
            }

            //validations depaul id
            if(String.IsNullOrEmpty(txtDePaulID.Text) || !Int32.TryParse(txtDePaulID.Text, out _depaulID) ||txtDePaulID.Text.Length != 7)
            {
                txtDePaulID.BorderColor = System.Drawing.Color.Red;
                lblDepaulIDErr.Text = "Depaul ID should be a Number and of Length 7";
                return false;
            }
            else
            {
                lblDepaulIDErr.Text = "";
                txtDePaulID.BorderColor = System.Drawing.Color.Black;
            }

            //email - regular expression 
            if (String.IsNullOrEmpty(txtEmail.Text) || !rgxEmail.IsMatch(txtEmail.Text))
            {
                txtEmail.BorderColor = System.Drawing.Color.Red;
                lblEmailErr.Text = "Incorrect Email Format";
                return false;
            }
            else
            {
                lblEmailErr.Text = "";
                txtEmail.BorderColor = System.Drawing.Color.Black;
            }

            //cellphone - regular expression 
            if (String.IsNullOrEmpty(txtCellphone.Text) || !regex.IsMatch(txtCellphone.Text) || txtCellphone.Text.Length > 12)
            {
                txtCellphone.BorderColor = System.Drawing.Color.Red;
                lblCellphoneErr.Text = "Cellphone format should be xxx-xxx-xxxx";
                return false;
            }
            else
            {
                lblCellphoneErr.Text = "";
                txtCellphone.BorderColor = System.Drawing.Color.Black;
            }

            return true;
        }
    }
}