﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proj4_Ahmed
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        private double _principal, _year;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            string calculatedAmount;
            if (isDoubleValidation())
             {
                foreach (ListItem list in rblYears.Items)
                {
                    if (list.Selected)
                    {
                        if (list.Text.Equals("15 Years"))
                            _year = Convert.ToDouble(list.Value); //double value 15
                        else if (list.Text.Equals("30 Years"))
                            _year = Convert.ToDouble(list.Value); //double value 30
                    }
                }

                //Breakdown computation of the Monthly Mortgage Payment formula
                //ddlInterestRate is the Slider (has Double Value)
                double rate_div = (Convert.ToDouble(ddlInterestRate.SelectedValue) / 1200.0);
                double rate_pow = Math.Pow((1.0 + rate_div), -12.00 * _year);

                double mortgage_h1 = (_principal * rate_div);
                double mortgage_h2 = (1 - rate_pow);

                //Final computation
                double ComputeMortgage = mortgage_h1 / mortgage_h2;

                //Adding the ComputeMortgage to String and showing output in Label
                calculatedAmount = "Result: " + Math.Round(ComputeMortgage, 2).ToString("C");
                lblCalculatedValue.Text = calculatedAmount.ToString();

               // _principal = 1000;
               // lblCalculatedValue.Text = "Result " + _year + " " + _principal;
            }
        }

        protected void rblYears_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rblYears.SelectedItem.Text.Equals("15 Years") || rblYears.SelectedItem.Text.Equals("30 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "0";
            }

            /*if(rblYears.SelectedItem.Text.Equals("15 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "";
                lblCalculatedValue.Text = "Result " + rblYears.SelectedItem.Value;
                
            }

            if (rblYears.SelectedItem.Text.Equals("30 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "";
                lblCalculatedValue.Text = "Result " + rblYears.SelectedItem.Value;
            }*/

            if (rblYears.SelectedItem.Text.Equals("Other"))
            {
                txtOtherYear.Enabled = true;
            }
        }

        protected void ddlInterestRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            //not implementing
        }

        protected void txtOtherYear_TextChanged(object sender, EventArgs e)
        {
            //lblCalculatedValue.Text = "Result " + txtOtherYear.Text;
        }

        private Boolean isDoubleValidation()
        {
            if (String.IsNullOrEmpty(txtPrincipal.Text) || !Double.TryParse(txtPrincipal.Text, out _principal))
            {
                txtPrincipal.BorderColor = System.Drawing.Color.Red;
                lblPrincipalError.Text = "Invalid Input!";
                return false;
            }
            else
            {
                lblPrincipalError.Text = "";
                txtPrincipal.BorderColor = System.Drawing.Color.Black;
            }


            if (String.IsNullOrEmpty(txtOtherYear.Text) || !Double.TryParse(txtOtherYear.Text, out _year))
            {
                txtOtherYear.BorderColor = System.Drawing.Color.Red;
                lblOtherYearError.Text = "Invalid Input!";
                return false;
            }
            else
            {
                lblOtherYearError.Text = "";
                txtOtherYear.BorderColor = System.Drawing.Color.Black;
            }

            return true;
        }

    }
}