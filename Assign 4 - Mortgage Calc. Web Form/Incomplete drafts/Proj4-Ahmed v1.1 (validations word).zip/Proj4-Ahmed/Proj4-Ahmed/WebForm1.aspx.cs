﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proj4_Ahmed
{
    public partial class WebForm1 : System.Web.UI.Page
    {

        private double _principal, _year;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {



            if (isDoubleValidation())
             {
                foreach (ListItem list in rblYears.Items)
                {
                    if (list.Selected)
                    {
                        if (list.Text.Equals("15 Years"))
                            _year = Convert.ToDouble(list.Value); //double value 15
                        else if (list.Text.Equals("30 Years"))
                            _year = Convert.ToDouble(list.Value); //double value 30
                    }
                }

                _principal = 1000;
                lblCalculatedValue.Text = "Result " + _year + " " + _principal;
            }
        }

        protected void rblYears_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rblYears.SelectedItem.Text.Equals("15 Years") || rblYears.SelectedItem.Text.Equals("30 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "";
            }

            /*if(rblYears.SelectedItem.Text.Equals("15 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "";
                lblCalculatedValue.Text = "Result " + rblYears.SelectedItem.Value;
                
            }

            if (rblYears.SelectedItem.Text.Equals("30 Years"))
            {
                txtOtherYear.Enabled = false;
                txtOtherYear.Text = "";
                lblCalculatedValue.Text = "Result " + rblYears.SelectedItem.Value;
            }*/

            if (rblYears.SelectedItem.Text.Equals("Other"))
            {
                txtOtherYear.Enabled = true;
            }
        }

        protected void ddlInterestRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            //not implementing
        }

        protected void txtOtherYear_TextChanged(object sender, EventArgs e)
        {
            //lblCalculatedValue.Text = "Result " + txtOtherYear.Text;
        }

        private Boolean isDoubleValidation()
        {
            if (String.IsNullOrEmpty(txtPrincipal.Text) || !Double.TryParse(txtPrincipal.Text, out _principal))
            {
                txtPrincipal.BorderColor = System.Drawing.Color.Red;
                lblPrincipalError.Text = "Invalid Input!";
                return false;
            }
            else
            {
                lblPrincipalError.Text = "";
                txtPrincipal.BorderColor = System.Drawing.Color.Black;
            }


            return true;
        }

    }
}