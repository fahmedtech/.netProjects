﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Proj2_Ahmed
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        double _principal;
        double _year;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void sldRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double NewValue = Math.Round(e.NewValue, 2);
            lblRate.Content = NewValue.ToString();
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            String CalculatedAmount;

            if (IsValidated())
            {

                //checking radio buttons values
                foreach(RadioButton button in stkYear.Children)
                {
                    if (button.IsChecked.Value)
                    {
                        if (button.Content.ToString() == "15 Years")
                            _year = 15.0;
                        else if (button.Content.ToString() == "30 Years")
                            _year = 30.0;
                        /*else
                            _year = txtOther.Text;*/
                    }
                }


                //breakdown computation of the monthly mortgage payment formula
                double rate_div = (sldRate.Value / 1200.0);
                double rate_pow = Math.Pow((1.0 + rate_div), -12.00 * _year);

                double mortgage_h1 = (_principal * rate_div);
                double mortgage_h2 = (1 - rate_pow);

                //final computation and output 
                double ComputeMortgage = mortgage_h1 / mortgage_h2;


                //adding to the string and label output
                CalculatedAmount = "Result: " + Math.Round(ComputeMortgage, 2).ToString("C");
                lblOutput.Content = CalculatedAmount.ToString();
            }
            //not correct, still working on it
           // double _principal = 0.0, _rate, year; 
        }

        private bool IsValidated()
        {

            //validating the principal amount
            
            if (String.IsNullOrEmpty(txtPrincipal.Text) || !Double.TryParse(txtPrincipal.Text, out _principal) || 
                _principal <= 0)
            {
                txtPrincipal.BorderBrush = new SolidColorBrush(Colors.Red);
                return false;
            }
            else
                txtPrincipal.BorderBrush = new SolidColorBrush(Colors.Black);


            //validating the other amount for Year
            if (String.IsNullOrEmpty(txtOther.Text) || !Double.TryParse(txtOther.Text, out _year) || _year <= 0)
            {
                txtOther.BorderBrush = new SolidColorBrush(Colors.Red);
                return false;
            }
            else
                txtOther.BorderBrush = new SolidColorBrush(Colors.Black);

            return true;
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            //resets the value(s) inside principal, Other, slider value and Result Labels
            txtPrincipal.Text = "0.00";
            txtOther.Text = "0";
            sldRate.Value = 0;
            lblOutput.Content = "$0.00";
        }
    }
}
